FAQ
//to have access to com/USB ports one can add the user to dialout group with command like
sudo usermod -a -G dialout $USER

//for test playing Music inside the editor needs vlc
sudo apt install vlc

//In order to get permanent access to FVT_linker you can add an udev rule file
sudoedit /etc/udev/rules.d/50-FVT-Linker.rules
//paste this line in there
KERNEL=="hidraw*", SUBSYSTEM=="hidraw", ATTRS{idVendor}=="10c4", ATTRS{idProduct}=="8468", TAG+="uaccess", GROUP="plugdev", MODE="0660"

//After saving the file log out or:
sudo udevadm control --reload-rules
sudo udevadm trigger